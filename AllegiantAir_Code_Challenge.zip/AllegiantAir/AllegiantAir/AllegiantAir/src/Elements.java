
public class Elements {
	
	//input data
	
	public static String departure = "Albany, NY (ALB)";
	public static String destination = "Daytona Beach / Sanford, FL (SFB)";
	public static String startDate = "Monday, February 28th 2022";
	public static String returnDate = "Monday, March 7th 2022";
	public static String bunbleType = "Allegiant Bonus";
	public static String firstNameValue = "Test User";
	public static String lastNameValue = "Last Name";
	public static String genderValue = "female";
	public static String month = "April";
	public static String day = "23";
	public static String year = "1996";
	
	
	//Home page or landing page
	
	public static String acceptCookies = "//button[contains(text(),'Accept All Cookies')]";
	public static String departurePath = "//div[contains(@data-hook,'flight-search-origin')]";
	
	public static String departureInput = "//input[@id='select-origin']";
	

	public static String destinationPath = "//*[contains(text(),'Destination, airport')]";

	public static String destinationInput = "//input[@id='select-destination']";
	
	public static String departureDate = "//*[contains(@data-hook,'flight-search-date-picker_expand-start-date')]";
	
	public static String startDateInput = "//button[@aria-hidden='false' and @aria-label='"+startDate+"']";
	
	public static String returnDateInput = "//button[@aria-hidden='false' and @aria-label='"+returnDate+"']";
	
	public static String search = "//button[@type='submit']";
	
	//flights
	
	public static String flights = "//span[text()='Flights']";
	
	public static String flightsContinue = "//button[contains(@data-hook,'page_continue')]";
	
	//bundles
	
	public static String bundles = "//span[text()='Select Your Bundle']";
	
	public static String allegiantBonus = "//button[@data-hook='select-tier-2']/parent::span";
	
	public static String allegiantTotal =  "//button[@data-hook='select-tier-3']/parent::span";
	
	public static String bundlesContinue = "//span[(text()='Continue')]";
	
	//Travelers 
	
	public static String travelers = "//span[text()='Who Will Be Traveling?']";
	
	public static String firstName = "//input[@type='text' and @placeholder='First Name']";
	
	public static String middleName = "//input[@type='text' and @placeholder='Middle Name']";
	
	public static String lastName = "//input[@type='text' and @placeholder='Last Name']";
	
	public static String suffix = "//div[contains(@data-hook,'travelers-form_adults_0_suffix')]";
	
	//gender
	
	public static String male = "//label[contains(@data-hook,'gender_MALE')]";
	
	public static String female = "//label[contains(@data-hook,'gender_FEMALE')]";
	
	public static String dobMonth = "//div[contains(@data-hook,'dob-month')]";
	public static String monthInput = "//input[contains(@id,'dob-month')]";
	public static String dobDay = "//div[contains(@data-hook,'dob-day')]";
	public static String dayInput = "//input[contains(@id,'dob-day')]";
	public static String dobYear = "//input[contains(@id,'dob-year')]";
	public static String yearInput = "//input[contains(@id,'dob-year')]";
	public static String phoneNumber = "//input[contains(@data-hook,'primary-phone-number')]";
	public static String email = "//input[contains(@data-hook,'form_adults_0_email')]";
	public static String travelContinue = "//button[contains(@data-hook,'page_continue')]";
	
	//Seats
	
	public static String seats = "//span[text()='Choose Departing Seats']";
	
	public static String autoSeating = "//button[contains(@class,'SeatsPageStyles__AutoSeatsToggle')]";
	
	public static String selectOk = "//button[contains(@data-hook,'seats-popover_seat_update_button')]";
	
	public static String displayBtn = "//span[contains(text(),'Great Choice!')]";
	
	public static String returnByn = "//button[@data-hook='seats-select-returning']";
	
	public static String continueBtn = "//button[contains(@data-hook,'continue-button-popup')]";
	
	//public static String okButton = "//div[contains(@class, 'SeatPopoverContent__Icon')]//following::span[contains(text(),'Great Choice!')][1]//following::button[1]/span[contains(text(),'Ok')]"; 
	
	public static String okButton = "//*[@id=\"id-07iknq\"]/div[2]/div/div/div/button"; 
	public static String skipSeatSelection = "//span[contains(text(),'No thanks, skip seat selection.')]"; 
	public static String bagsPage = "//span[contains(text(),\"Pick the Bags and Extras You Need\")]";
	public static String continueAlert = "//*[@id='main']/form/div/div[7]/div/div/div/div/button[2]";
	public static String TextViewInBagsPage = "//span[contains(text(), 'Know Which Items Cannot Travel With You')]";
	public static String hotelspage = "//span[contains(text(), 'Bundle Air + Hotel and Save!')]";
	public static String carsPage = "//span[contains(text(), 'Special Rental Car Deals')]";
	public static String noThanksLinkInCarsPage = "//span[contains(text(), 'No thanks')]";
	public static String closePopUpInPaymentsPage = "/html/body/div[9]/div/div/div/div/div";
	public static String departingFlightPrice = "//span[contains(text(), 'Departing Flight')]//following::p[contains(text(),'Selected')][1]//following::div[1]";
	public static String returningFlightPrice = "//span[contains(text(), 'Departing Flight')]//following::p[contains(text(),'Selected')][2]//following::div[1]";
	public static String finalPrice = "//span[contains(text(), 'You Pay Today:')]//following::span[1]";
	public static String deprtFlightString = "//span[contains(text(),'Departing Flight')]";
	public static String returnFlightString = "//span[contains(text(),'Returning Flight')]";
	//div[contains(@class, 'Checkbox__CheckboxWrapper')]
	
	
}
