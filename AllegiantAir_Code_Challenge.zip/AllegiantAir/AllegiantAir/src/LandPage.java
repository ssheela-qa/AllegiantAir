import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LandPage {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		Elements elements = new Elements();

		// System Property for Chrome Driver
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sheela\\Downloads\\ALGT\\AllegiantAir\\AllegiantAir\\driver\\chromedriver.exe");

		// Instantiate a ChromeDriver class.
		WebDriver driver = new ChromeDriver();

		// Launch Website
		driver.navigate().to("https://www.allegiantair.com");

		// Maximize the browser
		driver.manage().window().maximize();

		WebDriverWait wait = new WebDriverWait(driver, 10);

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//button[contains(@class,'Popup__CloseIcon')]")));

		driver.findElement(By.xpath("//button[contains(@class,'Popup__CloseIcon')]")).click();

		// Scroll down the webpage by 5000 pixels
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("scrollBy(0, 5000)");
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Accept All Cookies')]")));

		   Actions action1 = new Actions(driver);
		   action1.moveToElement(driver.findElement(By.xpath(elements.acceptCookies))).build().perform();
		
	
		driver.findElement(By.xpath(elements.acceptCookies)).click();

		Thread.sleep(1000);

		// driver.findElement(By.xpath("//span[contains(text(),'Round
		// Trip')]")).click();

		driver.findElement(By.xpath(elements.departurePath)).click();

		System.out.println(" after click ");

		Thread.sleep(2000);

		driver.findElement(By.xpath(elements.departureInput)).sendKeys(elements.departure);

		Thread.sleep(1000);

		driver.findElement(By.xpath(elements.departureInput)).sendKeys(Keys.ENTER);

		// To

		driver.findElement(By.xpath(elements.destinationPath)).click();

		System.out.println(" after click ");

		Thread.sleep(2000);

		// Actions action1 = new Actions(driver);
		// action1.moveToElement(driver.findElement(By.xpath(departurePath))).build().perform();

		driver.findElement(By.xpath(elements.destinationInput)).sendKeys(elements.destination);

		Thread.sleep(1000);

		driver.findElement(By.xpath(elements.destinationInput)).sendKeys(Keys.ENTER);

		System.out.println(" after destination");
		Thread.sleep(2000);
		driver.findElement(By.xpath(elements.departureDate)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(elements.startDateInput)).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath(elements.returnDateInput)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(elements.search)).click();

		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath(elements.flights)));
		
		
		js.executeScript("scrollBy(0, 1000)");
		
		Thread.sleep(2000);
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath(elements.flightsContinue)));
		
		action1.moveToElement(driver.findElement(By.xpath(elements.flightsContinue))).build().perform();

		try {
			
		driver.findElement(By.xpath(elements.flightsContinue)).click();
		System.out.println(" inside try after click ");
		}catch(Exception e) {
			
			System.err.println(" inside catch **************** "+e.getMessage());
			Thread.sleep(5000);
			driver.findElement(By.xpath(elements.flightsContinue)).click();
			
			System.out.println(" inside catch after click");
		}
		
		System.out.println(" bundles start");
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath(elements.bundles)));
		
		//js.executeScript("scrollBy(0, 1000)");
		
		if(elements.bunbleType.equalsIgnoreCase("Allegiant Bonus")) {
			
			Thread.sleep(1000);
			
			System.out.println(" inside bundle bonus ");
		
			action1.moveToElement(driver.findElement(By.xpath(elements.allegiantBonus))).build().perform();
			
			driver.findElement(By.xpath(elements.allegiantBonus)).click();
			
			System.out.println(" after click in bundle bonus ");
		}else {
			
			Thread.sleep(1000);
			
			System.out.println(" inside bundle total ");
			
			driver.findElement(By.xpath(elements.allegiantTotal)).click();
		}
		Thread.sleep(1000);
		driver.findElement(By.xpath(elements.bundlesContinue)).click();;
		
		System.out.println(" bundles end");
		
		Thread.sleep(4000);
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath(elements.travelers)));
		Thread.sleep(1000);
		driver.findElement(By.xpath(elements.firstName)).sendKeys(elements.firstNameValue);
		Thread.sleep(1000);
		driver.findElement(By.xpath(elements.lastName)).sendKeys(elements.lastNameValue);
		
		Thread.sleep(1000);
		if(elements.genderValue.equalsIgnoreCase("male")) {
			System.out.println(" inside male");
		driver.findElement(By.xpath(elements.male)).click();
		}else {
			System.out.println("inside female");
			driver.findElement(By.xpath(elements.female)).click();
		}
		
		Thread.sleep(1000);
		driver.findElement(By.xpath(elements.dobMonth)).click();
		driver.findElement(By.xpath(elements.monthInput)).sendKeys(elements.month);
		driver.findElement(By.xpath(elements.monthInput)).sendKeys(Keys.ENTER);
		
		Thread.sleep(1000);
		driver.findElement(By.xpath(elements.dobDay)).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(elements.dayInput)).sendKeys(elements.day);
		driver.findElement(By.xpath(elements.dayInput)).sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		//driver.findElement(By.xpath(elements.dobYear)).click();
		driver.findElement(By.xpath(elements.dobYear)).sendKeys(elements.year);
		//driver.findElement(By.xpath(elements.dobYear)).sendKeys(Keys.ENTER);
		
		System.out.println(" in travelers before continue");
		action1.moveToElement(driver.findElement(By.xpath(elements.travelContinue))).build().perform();
		driver.findElement(By.xpath(elements.travelContinue)).click();
		
		System.out.println(" travelers end");
		
		//Seats
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath(elements.seats)));
		
		driver.findElement(By.xpath(elements.autoSeating)).click();
		
		
		//driver.findElement(By.xpath(elements.selectOk)).getSize();
		
		wait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath(elements.displayBtn)));
		
		List<WebElement> options = driver.findElements(By.xpath(elements.selectOk));
		// Storing the result from the auto suggest in a list
		for(WebElement option :options){
			
			System.out.println(" inside for option "+option);
			if (option.isDisplayed()){
				
				System.out.println(" inside for inside if ");
			option.click();
	
			}
		}
		
		driver.findElement(By.xpath(elements.returnByn)).click();
	}

}
